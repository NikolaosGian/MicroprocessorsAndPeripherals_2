#include <platform.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <gpio.h>
#include <uart.h>
#include "leds.h"
#include "queue.h"

#define BUFF_SIZE 128

Queue rx_queue;

void uart_rx_isr(uint8_t rx) {
	// Store the received character
	queue_enqueue(&rx_queue, rx);
}

void switch_init(void){
	//#define P_SW_UP PA_1
	gpio_set_mode(P_SW_UP, Input); // 1 switch
}

int switch_get(Pin pin){
	return !gpio_get(pin); // active low
}

void LED_RED_ON_ISR(){
	leds_set(1,0,0);
}

void LED_GREEN_ON_ISR(){
	leds_set(0,1,0);
}

void LED_BLUE_ON_ISR(){
	leds_set(0,0,1);
}

void LEDS_OFF(){
	leds_set(0,0,0);
}


int main(){
	uint8_t rx_char = 0;
	int EINT1_IRQn = 21;
	int echo = 1 , counter = 0;
	char buff[BUFF_SIZE];
	uint32_t buff_index;
	
	queue_init(&rx_queue, 128);
	uart_init(57600);										// Baud -> 57600
	uart_set_rx_callback(uart_rx_isr);  // set reciver ISR
	uart_enable();											// enable to send char
	
	switch_init();
	leds_init();
	
	__enable_irq();
	
	NVIC_SetPriority(EINT1_IRQn,192);  					// Set uart with  lowest priority 
	uart_print("\r");
	
	while(1){
		uart_print("Enter your second name: ");
		buff_index = 0;
		do{
			while(!queue_dequeue(&rx_queue, &rx_char))
			__WFI();
			if(rx_char == 0x7F){ // Handle backspace character
				if(buff_index > 0){
					buff_index--;
					if (echo) {
						uart_tx(rx_char);
					}
				}
			
			} else if  ((rx_char >= 'a' && rx_char <= 'z') || (rx_char >= 'A' && rx_char <= 'Z') || rx_char == ' ' || rx_char == '\r'){
				// Store character
				buff[buff_index++] = (char) rx_char;
				if (echo) {
					uart_tx(rx_char);
				}
			} 
		}	while ( rx_char != '\r' && buff_index < BUFF_SIZE );
			buff[buff_index - 1] = '\0';
			if (echo) {
				uart_print("\r\n");
			}
			
			if (buff_index < BUFF_SIZE)
			{
				if(buff[buff_index - 1] == 'e' || buff[buff_index - 1] == 'y' ||
					 buff[buff_index - 1] == 'u' || buff[buff_index - 1] == 'i' || 
					 buff[buff_index - 1] == 'o' || buff[buff_index - 1] == 'a' 
					|| buff[buff_index - 1] == 'E' || buff[buff_index - 1] == 'Y' ||
					 buff[buff_index - 1] == 'U' || buff[buff_index - 1] == 'I' || 
					 buff[buff_index - 1] == 'O' || buff[buff_index - 1] == 'A' )
				{
					
					uart_print("Red Led ON!");
					LED_RED_ON_ISR();
				} else if( buff[buff_index - 1] == 'q' || buff[buff_index - 1] == 'w' ||
					 buff[buff_index - 1] == 'r' || buff[buff_index - 1] == 't' || 
					 buff[buff_index - 1] == 'p' || buff[buff_index - 1] == 's' ||
					 buff[buff_index - 1] == 'd' || buff[buff_index - 1] == 'f' || 
					 buff[buff_index - 1] == 'g' || buff[buff_index - 1] == 'h' ||
					 buff[buff_index - 1] == 'j' || buff[buff_index - 1] == 'k' ||
				   buff[buff_index - 1] == 'l' || buff[buff_index - 1] == 'z' ||
					 buff[buff_index - 1] == 'x' || buff[buff_index - 1] == 'c' || 
					 buff[buff_index - 1] == 'v' || buff[buff_index - 1] == 'b' || 
				   buff[buff_index - 1] == 'n' || buff[buff_index - 1] == 'm'
					 || buff[buff_index - 1] == 'Q' || buff[buff_index - 1] == 'W' ||
					 buff[buff_index - 1] == 'R' || buff[buff_index - 1] == 'T' || 
					 buff[buff_index - 1] == 'P' || buff[buff_index - 1] == 'S' ||
					 buff[buff_index - 1] == 'D' || buff[buff_index - 1] == 'F' || 
					 buff[buff_index - 1] == 'G' || buff[buff_index - 1] == 'H' ||
					 buff[buff_index - 1] == 'J' || buff[buff_index - 1] == 'K' ||
				   buff[buff_index - 1] == 'L' || buff[buff_index - 1] == 'Z' ||
					 buff[buff_index - 1] == 'X' || buff[buff_index - 1] == 'C' || 
					 buff[buff_index - 1] == 'V' || buff[buff_index - 1] == 'B' || 
				   buff[buff_index - 1] == 'N' || buff[buff_index - 1] == 'M')
				{
					 
					uart_print("Green Led ON!");
					LED_GREEN_ON_ISR();
				} else if(switch_get(P_SW_UP) == 1)
				{
						if (counter < 1){	
							uart_print("BLUE Led ON!");
							LED_BLUE_ON_ISR();
							counter++;
							
						} else{
								uart_print("BLUE Led OFF!");
								LEDS_OFF();
								counter = 0;
						}
				}
			}
		}		
	}
