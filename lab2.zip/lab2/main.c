#include <platform.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <gpio.h>
#include <uart.h>
#include "leds.h"
#include "queue.h"

#define BUFF_SIZE 128

Queue rx_queue;

int counter =0;

void uart_rx_isr(uint8_t rx) {
	// Store the received character
	queue_enqueue(&rx_queue, rx);
}

void switch_init(void){
	//#define P_SW PC13
	gpio_set_mode(P_SW, PullUp); // 1 switch
	
}

int switch_get(Pin pin){
	return !gpio_get(pin); // active low
}

void LED_RED_ON_ISR(){
	leds_set(1,0,0);
}

void LED_GREEN_ON_ISR(){
	leds_set(0,1,0);
}

void LED_BLUE_ON_ISR(){
	leds_set(0,0,1);
}

void LEDS_OFF(){
	leds_set(0,0,0);
}

void OnPressButton_isr(){
	if ( counter < 1){
		uart_print("BLUE LED ON! \r\n");
		LED_BLUE_ON_ISR();
		counter++;
		uart_print("Enter your second name: \r\n");
	}else{
		uart_print("BLUE LED OFF! \r\n");
		LEDS_OFF();
		counter = 0;
		uart_print("Enter your second name: \r\n");
	}

	
}

int main(){
	uint8_t rx_char = 0;
	int EINT1_IRQn = 21;
	int echo = 1 ;
	char buff[BUFF_SIZE];
	uint32_t buff_index;
	
	queue_init(&rx_queue, 128);
	uart_init(9600);										// Baud -> 9600
	uart_set_rx_callback(uart_rx_isr);  // set reciver ISR
												
	
	switch_init();
	gpio_set_trigger(P_SW, Rising);
	gpio_set_callback(P_SW, OnPressButton_isr);
	

	leds_init();
	uart_enable();
	__enable_irq();// enable to send char
	
	NVIC_SetPriority(EINT1_IRQn,192);  					// Set uart with  lowest priority 
	uart_print("\r");
	
	while(1){
		
		uart_print("Enter your second name: \r\n");
		buff_index = 0;
		do{
			while(!queue_dequeue(&rx_queue, &rx_char))
			__WFI();
			if(rx_char == 0x7F){ // Handle backspace character
				if(buff_index > 0){
					buff_index--;
					if (echo) {
						uart_tx(rx_char);
					}
				}
			
			} else if  ((rx_char >= 'a' && rx_char <= 'z') || rx_char == ' ' || rx_char == '\r' || rx_char == '\n'){
				// Store character
				buff[buff_index++] = (char) rx_char;
				if (echo) {
					uart_tx(rx_char);
				}
			} 
		}	while ( rx_char != '\r' && buff_index < BUFF_SIZE );
			buff[buff_index - 1] = '\0';
			if (echo) {
				uart_print("\r\n");
			}
			
			if (buff_index < BUFF_SIZE){
				if(buff[buff_index - 2] == 'a' || buff[buff_index - 2] == 'e' ||
					 buff[buff_index - 2] == 'o' || buff[buff_index - 2] == 'u' || 
					 buff[buff_index - 2] == 'i' )
				{
					
					uart_print("Red Led ON!\r\n");
					LED_RED_ON_ISR();
					echo = 1;
				} else if( buff[buff_index - 2] == 'k' || buff[buff_index - 2] == 'p' ||
					 buff[buff_index - 2] == 't' || buff[buff_index - 2] == 'b' || 
					 buff[buff_index - 2] == 'd' || buff[buff_index - 2] == 'c' ||
					 buff[buff_index - 2] == 'h' || buff[buff_index - 2] == 'f' || 
					 buff[buff_index - 2] == 'j' || buff[buff_index - 2] == 'l' ||
					 buff[buff_index - 2] == 'r' || buff[buff_index - 2] == 'g' ||
				   buff[buff_index - 2] == 's' || buff[buff_index - 2] == 'm' ||
					 buff[buff_index - 2] == 'n')
				{
					 
					uart_print("Green Led ON!\r\n");
					LED_GREEN_ON_ISR();
					echo =1;
				} 
				else{
					uart_print("Unknown Command!\r\n");
				}
			}
		}		
	}
